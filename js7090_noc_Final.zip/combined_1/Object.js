"use strict";

class DepthObject {
  constructor() {
    this.depthVal = int(random(40));
  }
  
  display(){
    
  }
}



