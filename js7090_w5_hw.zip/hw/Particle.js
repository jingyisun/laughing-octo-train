"use strict";

var cD = 0.01;
var cS = 370;

class Particle {
  constructor(x, y, vy) {
    this.pos = createVector(x, y);
    this.vel = createVector(random(5, 50), vy);
    this.acc = createVector(0, 0);
    this.rad = 1;
    this.mass = random(2, 8)
  }

  applyForce(force) {
    force.div(this.mass);
    this.acc.add(force);
  }

  applyGravity() {
    var vector = createVector(0, 0.98);
    var gravity = p5.Vector.mult(vector, g * this.mass);
    this.applyForce(gravity);
  }

  applyAirResistance(force) {
    var speed = this.vel.mag();
    var drag = p5.Vector.mult(this.vel, -1);
    drag.normalize()
    var ar = drag.mult(cD * speed * speed);
    this.applyForce(ar);
  }

  update() {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.mult(0);

  }

  applySuction() {
    var topVec = createVector(width / 2, 0);
    var sucDir = p5.Vector.sub(topVec, this.pos);
  // sucDir.normalize();
  // var suction = sucDir.mult(cS);
    this.applyForce(sucDir);

  }

  checkEdges() {
    if (this.pos.y > height) {
      this.pos.y = height;
      this.vel.y = -this.vel.y;
      this.vel.mult(0.3);
      if(mouseIsPressed){
      this.applySuction();
}
    }

    // if (this.pos.y < 0) {
    //   for (var i = 0; i < 10; i++) {
    //     pXP.pop();
    //     pPP.pop();
    //   }

    // }
  }

  display() {
    push();
    translate(this.pos.x, this.pos.y);
    noStroke();
    fill(255);
    ellipse(0, 0, this.rad * 2 * this.mass, this.rad * 2 * this.mass);
    pop();
  }
}