var pXP = [];
var pPP = []
var g = 0.98;

function setup() {
  createCanvas(1200, 600);
  background(0);
  for (var i = 0; i < 10; i++) {
    pXP.push(new Particle(100, height, random(-50, -30)));
  }

  for (var j = 0; j < 10; j++) {
    pPP.push(new Particle(0, 0, 0));
  }
}

function draw() {
  background(0);

  for (var a = 0; a < pXP.length; a++) {
   p1 = pXP[a];
    p2 = pPP[a];

    

    p1.applyGravity();
    p1.applyAirResistance();

    p1.update();
    p1.checkEdges();
    p1.display();

  
    p2.applyGravity();
    p2.applyAirResistance();

    p2.update();
    p2.checkEdges();
    p2.display();
  }


}