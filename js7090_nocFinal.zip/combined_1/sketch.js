var objects = [];
var boids = [];

var angle, b1, b2;

function setup() {
  createCanvas(1000, 600);
  //background(0);

  angle = PI / 6;
  c1 = color(0, 40, 60, 150);
  c2 = color(0, 150);


  noStroke();
  fill(200, 120, 10, 70);

  for (var i = 0; i < 30; i++) {
    objects.push(new Boid(random(width), random(height)));
    boids[i] = objects[i];
    //print(boids[i].depthVal);
  }

  for (var i = 0; i < 12; i++) {
    objects.push(new Tree(80, 20, 30, 250));
  }
  for (var i = 0; i < 10; i++) {
    objects.push(new Tree(100, 15, 30, 200));
  }
  for (var i = 0; i < 8; i++) {
    objects.push(new Tree(150, 13, 20, 160));
  }
  for (var i = 0; i < 6; i++) {
    objects.push(new Tree(200, 9, 20, 80));
  }
  for (var i = 0; i < 4; i++) {
    objects.push(new Tree(300, 0, 0, 0));
  }


}

function draw() {
  setGradient(c1, c2);

  objects.sort(function(a, b) {
    return a.depthVal - b.depthVal;
  });

  //update boids
  for (var i = 0; i < boids.length; i++) {
    boids[i].flock(boids);
    boids[i].update();
    boids[i].checkEdges();
  }

  for (var i = 0; i < objects.length; i++) {
    // flies & trees display
    objects[i].display();
  }
}



function setGradient(c1, c2) {
  for (var i = 0; i <= height; i++) {
    var inter = map(i, 0, height, 0, 1);
    var c = lerpColor(c1, c2, inter);
    stroke(c);
    line(0, i, width, i);
  }
}