"use strict";

class Tree extends DepthObject {
  constructor(len, shadeG, shadeB, depth) {
    super();
    this.pg = createGraphics(1000, 600);
    this.pg.pixelDensity(1);
    this.depthVal = len / 10;
    this.id = 1;

    // init
    this.create(len, shadeG, shadeB, depth);
  }
  create(len, shadeG, shadeB, depth) {
    this.pg.push();
    this.pg.translate(random(this.pg.width), this.pg.height - depth);
    branch(this.pg, len, shadeG, shadeB);
    this.pg.pop();
  }

  display() {
    image(this.pg, 0, 0);
  }
  run() {
    this.display();
  }
}

function branch(pg, len, shadeG,shadeB) {
  var sw = map(len, 0, 200, 1, 30);
  pg.strokeWeight(sw);
  pg.stroke(0, shadeG, shadeB);
  pg.line(0, 0, 0, -len);

  pg.translate(0, -len);
  len = len * 2 / 3 * random(0.7, 1.3);

  if (len > 10) {
    pg.push();
    pg.rotate(angle + random(-0.3, 0.3));
    branch(pg, len, shadeG, shadeB);
    pg.pop();

    pg.push();
    pg.rotate(-angle + random(-0.3, 0.3));
    branch(pg, len, shadeG, shadeB);
    pg.pop();
  }
}