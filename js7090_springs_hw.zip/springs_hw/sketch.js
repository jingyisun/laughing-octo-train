var balls = [];
var springs = [];
var j = 30;

function setup() {
  createCanvas(500, 600);
  for (var y = 100; y < width + 100; y += 200) {
    for (var x = 50; x < width - 40; x += 50) {
      balls.push(new Ball(x, y));
    }
  }

  for (var sy = 30; sy < width; sy += 200) {
    line(0, sy, width, sy);
    for (var sx = 50; sx < width - 40; sx += 50) {
      springs.push(new Spring(sx, sy, 100));
    }
  }
}

function draw() {
  background(255);
  stroke(0,100,150);
  line(0, j, width, j);
  line(0, 200 + j, width, 200 + j);
  line(0, 400 + j, width, 400 + j);


  for (var i = 0; i < balls.length; i++) {
    springs[i].connect(balls[i]);
    springs[i].display(balls[i]);

    var gravity = createVector(0, 1);
    balls[i].applyForce(gravity);

    balls[i].display();
    balls[i].update();
    balls[i].drag();
  }
}