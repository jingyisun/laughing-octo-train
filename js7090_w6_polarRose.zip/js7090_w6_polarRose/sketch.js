var n, d, k;
 
function setup() {
  createCanvas(500, 500);
  background(0);
}

function draw() {
  background(0);
  // var n = sin(frameCount * 0.02) * 2;
  // var d = sin(frameCount * 0.01) * 4;

  // var n = sin(frameCount * 0.02) ;
  // var d = sin(frameCount * 0.01) * 10;

  var n = 3;
  var d = sin(frameCount * 0.001) * 10;
  var k = n / d;

  push();
  translate(width / 2, height / 2);
  for (var t = 0; t < TWO_PI * d; t += 0.01) {

    var r = 200 * cos(k * t);
    var x = r * cos(t);
    var y = r * sin(t);

    ellipse(x, y, 2, 2);

  }
  pop();
}