"use strict";

class Planet {
  constructor(x, y, _rad, r, g, b) {
    this.pos = createVector(x, y);
    this.rad = _rad;
    this.g = 0.7; //cGravity coefficientGravity
    this.cW = 0.1;
    this.gS = 0.9;
    this.pcolor = color(r, g, b);
    this.orbitSpd = random(0.001, 0.003);
    this.angle = random(TWO_PI);

  }
  update() {
    //
  }

  orbit() {
    this.angle = this.angle + this.orbitSpd;
    rotate(this.angle);
    
  }
  
  display() {
    push();
    noStroke();
    fill(this.pcolor);
    ellipse(this.pos.x, this.pos.y, this.rad * 2, this.rad * 2)
    pop();
  }

}