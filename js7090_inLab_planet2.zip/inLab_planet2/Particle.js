"use strict";

var dx, dy, d;
var collision = false;

class Particle {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.vel = createVector(random(-5, 5), random(-5, 5));
    this.acc = createVector(0,0);
    this.rad = 1;
    this.mass = random(2, 5);
    this.accAdj = random(0.02, 0.2);
  }

  applyForce(f) {
    f.div(this.mass);
    this.acc.add(f);
  }


  update() {
    this.acc.mult(this.accAdj);
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.mult(0);
  }

  display() {
    push();
    translate(this.pos.x, this.pos.y);
    noStroke();
    fill(255);
    ellipse(0, 0, this.rad * 2 * this.mass, this.rad * 2 * this.mass);
    pop();
  }
}