var earth;
var particles = [];

function setup() {
  createCanvas(1200, 800);
  earth = new Planet(-200, -200, 60, 0, 0, 200);
  sun = new Planet(0, 0, 150, 200, 100, 0);

  for (var i = 0; i < 30; i++) {
    particles.push(new Particle(random(-width + 100, width - 100), random(-height + 100, height - 100)));
  }
}

function draw() {
  background(0);
  push();
  translate(width / 2, height / 2);

  sun.display();
  earth.orbit();
  earth.display();



  for (var i = 0; i < particles.length; i++) {
    var p = particles[i];

    var gravityE = p5.Vector.sub(earth.pos, p.pos);
    gravityE.normalize();
    gravityE.mult(earth.g * p.mass);
    p.applyForce(gravityE);

    var gravityS = p5.Vector.sub(sun.pos, p.pos);
    gravityS.normalize();
    gravityS.mult(sun.gS * p.mass);
    p.applyForce(gravityS);

    //var distance = dist(x,y,tX,tY);
    var distanceE = dist(earth.pos.x, earth.pos.y, p.pos.x, p.pos.y);
    if (distanceE < earth.rad / 2) {
      p.vel = createVector(random(-1, 1), random(-1, 1));
    } else if (distanceE <= earth.rad) {
      var resistance = p5.Vector.mult(p.vel, -1);
      resistance.normalize();
      var speed = p.vel.mag();
      resistance.mult(speed * speed * earth.cW);
      resistance.limit(speed);
      p.applyForce(resistance);
    }

    var distanceS = dist(sun.pos.x, sun.pos.y, p.pos.x, p.pos.y);
    if (distanceS < sun.rad) {
      p.vel = createVector(100,0);
    } else if (distanceS <= sun.rad + p.rad + 50) {
      p.vel.mult(-2);
      p.vel.limit(95);
    }


    p.update();
    p.display();
  }

  pop();
}