"use strict";

class Circle {
  constructor(x, y, xspd, yspd) {
    this.x = x;
    this.y = y;
    this.dia = random(5, 10);
    this.xspd = xspd;
    this.yspd = yspd;
    this.distance = 0;
    this.timeCounter = 200;
  }

  move() {
    this.x += this.xspd;
    this.y += this.yspd;
  }

  squiggle() {
    this.xspd = random(-1, 1) * 20;
    //this.yspd = random(-1, 1) * 20;
  }

  applyGravity(g) {
    this.yspd += g;
  }

  reduceSpd(amt) {
    this.xspd *= amt;
    this.yspd *= amt;
  }

  run() {
    this.move();
    if (this.timeCounter > 0) {
      this.timeCounter--;
      this.reduceSpd(0.98);
      this.displayBfrExp();
    } else{
      this.displayAfterExp();
    }
  }


  displayBfrExp() {
    push();
    fill(255);
    noStroke();
    fill(255 - frameCount);
    ellipse(this.x, this.y, this.dia, this.dia);
    pop();

  }

  displayAfterExp() {
    this.distance += 0.2;
    for (var i = 0; i < 10; i++) {
      for (var angle = 0; angle < 360; angle += 12) {
        push();
        translate(this.x, this.y);
        rotate(frameCount * 0.01);
        rotate(radians(angle)); //radians, but 360 degree
        fill(255 - this.distance * 20, 150 - this.distance * 20, 170 - this.distance * 20);
        noStroke();
        ellipse(0, (0 + this.distance) * i, this.dia, this.dia);
        pop();
      }
    }
  }


}