var circles = [];
var NUM_OF_CIRCLES = 1; //whole letter capital == constant

function setup() {
  createCanvas(800, 800);
  background(0);

  for (var i = 0; i < NUM_OF_CIRCLES; i++) {
    circles.push(new Circle(width / 2, height, 0, random(-16, -10)));

  }

}

function draw() {
  background(0, 20);
  for (var i = 0; i < circles.length; i++) {
    circles[i].run();
  }
}