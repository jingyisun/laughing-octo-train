var boids = [];

function setup() {
  createCanvas(1000, 600);
  background(0);
  noStroke();
  fill(200,120,10,70);
  for (var i = 0; i < 20; i++) {
    boids.push(new Boid(random(width), random(height)));
  }
}

function draw() {
  background(0,175);
  
  for (var i = 0; i < boids.length; i++) {
    var b = boids[i];
    b.flock(boids);
    b.update();
    b.checkEdges();
    push();
    blendMode(ADD);
    b.display();
    pop();
  }
}