"use strict";
class Circle {
  constructor(x, y, xspd, yspd) {
    this.pos = createVector(x, y);
    //this.x = x;
    //this.y = y;

    this.dia = random(5, 10);

    this.vel = createVector(xspd, yspd);
    // this.xspd = xspd;
    // this.yspd = yspd;

    this.distance = 0;
    this.timeCounter = 80;

    this.expSpeed = 25;
    this.expReduction = .05;

    this.falpha = 240;
    this.fcolor = color(random(255), random(255), random(255));

    this.spinAngle = 0.0;
    this.spinSpeed = 0.15;

  }

  update() {
    this.vel.x = random(-0.5, 0.5);
    this.pos.add(this.vel);
  }

  /* 
  move() {
     this.x += this.xspd;
     this.y += this.yspd;
   }

  squiggle() {
    this.xspd = random(-0.5, 0.5);
    //this.yspd = random(-1, 1) * 20;
  }
   */

  reduceSpd(amt) {
    this.vel.mult(amt);
    /*
    this.xspd *= amt;
    this.yspd *= amt;
    */
  }

  fadeAway() {

    if (this.falpha > 0) {
      this.falpha -= 6;
    }
  }

  run() {

    if (this.timeCounter >= 0) {
      this.timeCounter--;
      this.update();
      this.reduceSpd(0.95);
      //this.squiggle();
      this.displayBfrExp();

    } else {
      this.fadeAway();
      this.displayAfterExp();

    }
  }


  displayBfrExp() {
    push();
    fill(this.fcolor);
    noStroke();
    ellipse(this.pos.x, this.pos.y, this.dia, this.dia);
    pop();

  }

  displayAfterExp() {
    this.distance += this.expSpeed;
    this.expSpeed *= this.expReduction;
    
    this.spinAngle += this.spinSpeed;
    this.spinSpeed *= 0.9;


    for (var i = 0; i < 7; i++) {
      for (var angle = 0; angle < 360; angle += 18) {
        push();
        translate(this.pos.x, this.pos.y);

        //rotate(frameCount*0.02) //spirals out
        rotate(this.spinSpeed); //spirals out
        rotate(radians(angle)); //radians, but 360 degree

        fill(red(this.fcolor), green(this.fcolor), blue(this.fcolor), this.falpha);
        noStroke();
        ellipse(0, (0 + this.distance) * i, random(2, 7), random(3, 8));
        pop();
      }
    }
  }



}